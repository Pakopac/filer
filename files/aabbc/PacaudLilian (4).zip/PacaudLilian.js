function exercice_1(data){
    var name = data[0].name;
    var age = data[0].age;
    for(var i in data){
        if(data[i].age < age){
            age = data[i].age;
            name = data[i].name;
        }
    }
    return name;
}

function exercice_2(data){
    var name = data[0].name;
    var age = 0;
    for (var i in data){
        if(data[i].age > age) {
            age = data[i].age;
            name = data[i].name;
        }
    }
    return name
}

function exercice_3(data) {
    var name = data[0].name;
    var salary = 0;
    for (var i in data) {
        if (data[i].salary > salary) {
            salary = data[i].salary;
            name = data[i].name;
        }
    }
    return name
}

function exercice_4(data) {
    var Salary = 0;
    var totalSalary = 0;
    for (var i in data) {
        var prime = 0;
        for (var j in data[i].primes) {
            prime = prime + data[i].primes[j];
        }
        totalSalary = prime + data[i].salary;
        if (totalSalary > Salary) {
            var name = data[i].name;
        }
    }
    return name;
}

function exercice_5(data, sex){
    var male = [];
    var female = [];
    for (var i in data){
        var value = data[i].sex;
        if(sex == "m"){
            data[i].sex = "m";
            male.push(data[i]);
        }
        return male;
        if(sex == "f"){
            data[i].sex = "f";
            female.push(data[i]);
        }
        return female;
    }

}

function exercice_6(data, dpt){

}