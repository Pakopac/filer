<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Triangle de Pascal</title>
    <style>
        table { border-collapse: collapse; }
        td { text-align: center; padding: 0px 5px; border: 1px solid black; box-sizing: border-box; }
    </style>
  </head>
  <body>
    <form action="pascal.php" method="POST">
      <label for="depth">Profondeur : </label>
        <input type="number" id="depth" name="depth"  min="1" max="100" value=
            "<?php
            if(isset($_POST['depth'])){
                $depth = $_POST['depth'];
            }
            else{
                $depth = NULL;
            }
            echo "$depth";
            ?>">
      <input type="Submit">
    </form>
    <h1>
	    <?php
            if (0 < $depth && $depth <= 30) {
                echo "Triangle de profondeur" . "\n" . $depth;
            } elseif (30 < $depth) {
                echo "Triangle de profondeur" . "\n" . "30";
            }
        ?>
    </h1>
    <table>
        <?php
            if (30 > $depth) {
                for ($l = 1; $l <= $depth; $l++) {
                    echo "<tr>";
                    for ($c = 1; $c <= $l; $c++) {
                        if ($c == 1 || $c == $l) {
                            $table[$l][$c] = 1;
                        }
                        else {
                            $table[$l][$c] = $table[$l - 1][$c - 1] + $table[$l - 1][$c];
                        }
                        echo "<td colspan=" .($depth * $depth / ($l)) . '>' . $table[$l][$c] . "</td>";
                    }
                    echo "</tr>";
                }
            } else {
                for ($l = 1; $l <= 30; $l++) {
                    echo "<tr>";
                    for ($c = 1; $c <= $l; $c++) {
                        if ($c == 1 || $c == $l) {
                            $table[$l][$c] = 1;
                        }
                        else {
                            $table[$l][$c] = $table[$l - 1][$c - 1] + $table[$l - 1][$c];
                        }
                        echo "<td colspan=" .(30 * 30 / ($l)).  '>' . $table[$l][$c] . "</td>";
                    }
                    echo "</tr>";
                }
            }
        ?>
    </table>
  </body>
</html>
