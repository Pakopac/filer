$(function () {

    $('form').submit(function () {
        var pseudo = $(this).find(':text[name="pseudo"]').val();
        var password = $(this).find(':password[name="password"]').val();

        localStorage.setItem('pseudo', JSON.stringify(pseudo));
        localStorage.setItem('password', JSON.stringify(password));

        var getPseudo = localStorage.getItem("pseudo");

        $('form').css('display', 'none');
        $('body').html('Acceuil - connected as' +'<br>'+ getPseudo);
        return false;
    });
});