window.onload = function () {
    var imgAll = document.querySelectorAll('.imgWoman, .imgMan');
    var description = document.querySelector('#blockDescription');
    var imgWoman = document.querySelectorAll('.imgWoman');
    var imgMan = document.querySelectorAll('.imgMan');
    function descriptionImg(descrip){
        description.style.display='block';
        description.innerHTML = descrip;
    }
    function visibility(img, visibility){
        for(var i = 0; i < img.length; i++) {
            img[i].style.visibility = visibility;
        }
    }
    imgAll[0].onclick = function(){
        descriptionImg('Asakura: Le dieu comme on l\' appelle, une légende vivante.')
    }
    imgAll[1].onclick = function(){
        descriptionImg('Serena: Belle et charismatique, la waifu ultime')
    }
    imgAll[2].onclick = function(){
        descriptionImg('Sai: Shinobi mystèrieux et intéressant (pas comme Sasuke !!)')
    }
    imgAll[3].onclick = function(){
        descriptionImg('Ryuko: Ne la cherchez pas trop... vous pourriez y rester !!')
    }
    document.getElementById('hide').onclick = function(){
        description.style.display='none';
    }
    document.getElementById('showWomen').onclick = function(){
        visibility(imgWoman, 'visible');
        visibility(imgMan, 'hidden');
    }
    document.getElementById('showMen').onclick = function(){
        visibility(imgMan, 'visible');
        visibility(imgWoman, 'hidden');
    }
    document.getElementById('showAll').onclick = function(){
        visibility(imgAll, 'visible');
    }
}